"""Provide single-source for meta."""

__version__ = "0.0.1"