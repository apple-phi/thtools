from thtools import app # absolute import to allow packaging with Pyinstaller

app.eel.start("index.html", size=(1920, 1080))
