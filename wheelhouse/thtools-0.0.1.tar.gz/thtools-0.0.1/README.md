<!-- <p align="center">
    <img src="thtools/web/favicon.png" width="200" height="200"/>
</p> -->
## thtools
A library for the analysis of toehold switch riboregulators made by the iGEM team City of London UK 2021

## License
[MIT](LICENSE)