"""Initialize pkg."""

from . import _meta

import os
HOME = os.path.dirname(os.path.abspath(__file__))

from .analysis import *
from .utility import *
from . import demos
